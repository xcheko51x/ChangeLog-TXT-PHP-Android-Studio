package com.xcheko51x.changelog;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.Hashtable;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    String URL_SERVIDOR = "http://192.168.0.11/PruebasCanal/VerifcaCambios.php";

    TextView tvCambios;

    String version;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("ChangeLog");

        tvCambios = findViewById(R.id.tvCambios);

        verificarCambios();

    }

    public void verificarCambios() {

        SharedPreferences preferences = getSharedPreferences("PREFERENCIAS", MODE_PRIVATE);
        version = preferences.getString("version", "");


        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_SERVIDOR,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(final String response) {
                        // En este apartado se programa lo que deseamos hacer en caso de no haber errores
                        //tvCambios.setText(response);

                        if((version == "") || (version.equals(response.trim()) == false))  {

                            if(version == "") {
                                tvCambios.setText("NO EXISTE VERSIÓN\n");
                            } else if(version.equals(response.trim()) == false) {
                                tvCambios.setText(
                                        "HAY UNA NUEVA VERSIÓN\n" + "Tu: " + version +"\nActual: " + response
                                );
                            }

                            AlertDialog.Builder dialogo = new AlertDialog.Builder(MainActivity.this);
                            dialogo.setTitle("ACTUALIZACIÓN");
                            dialogo.setMessage("Hay una nueva actualización");
                            dialogo.setCancelable(true);
                            dialogo.setPositiveButton("ACTUALIZAR", new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    SharedPreferences.Editor editor = getSharedPreferences("PREFERENCIAS", MODE_PRIVATE).edit();
                                    editor.putString("version", response.trim());

                                    editor.commit();

                                    Toast.makeText(MainActivity.this, "SE ACTUALIZO LA APLICACIÓN", Toast.LENGTH_LONG).show();

                                }

                            });

                            dialogo.show();

                        } else if(version.equals(response) == true) {
                            tvCambios.setText("ESTA ACTUALIZADO\n" + response);
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // En caso de tener algun error en la obtencion de los datos
                tvCambios.setText("ERROR");
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                // En este metodo se hace el envio de valores de la aplicacion al servidor

                Map<String, String> parametros = new Hashtable<String, String>();
                parametros.put("versionApp", version.trim());

                return parametros;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}
